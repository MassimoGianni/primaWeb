namespace Giannini.Massimo._5i.PrimaWeb.Models
{
    public class ErrorViewModel
    {
        public string? RequestId { get; set; }
        public string? Nome { get; set; } // Aggiunto il campo Nome
        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}